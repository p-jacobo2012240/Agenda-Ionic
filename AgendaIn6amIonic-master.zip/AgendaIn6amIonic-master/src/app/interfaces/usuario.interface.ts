export interface IUsuario {
  idUsuario?:number;
  nick:string;
  contrasena:string;
  cambios_contrasena?:number;
  fecha_modificacion?:string;
}
